document.getElementById("submit").addEventListener("click", calculate);

function calculate() {
  const fName = document.getElementById('fname').value;
  const lName = document.getElementById('lname').value;
  try {
    if (isNumeric(fName.charAt(0)) || isNumeric(lName.charAt(0))) {
      throw new Error("The first letter cannot be a digit");
    }
  }
  catch (err) {
    console.error(err.message)
  }
  document.getElementById('result').innerHTML = fName + lName;
}

function isNumeric(str) {
  return !isNaN(str) && !isNaN(parseFloat(str))
}